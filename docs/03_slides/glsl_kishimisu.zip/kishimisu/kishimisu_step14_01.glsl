/* 
    Code by kishimisu
    ShaderToy: https://www.shadertoy.com/view/mtyGWy
    Tutorial: https://youtu.be/f4s1h2YETNY
*/


#ifdef GL_ES
precision mediump float;
#endif

uniform vec2 u_resolution;
uniform float u_time;

#define PI 3.14159265359





// STEP_7a
// CREATING A COLOR RAMP AND
// SAMPLING IT WITH t
// https://iquilezles.org/articles/palettes/
// https://www.youtube.com/shorts/TH3OTy5fTog
// Inigo: "As t runs from 0 to 1 
// (our normalized palette index or domain), 
// the cosine oscillates 'freq' times with a phase of 'phase'. 
// The result is scaled and biased by 'offset' and 'amp' to 
// meet the desired contrast and brightness."
// This function shapes a cosine function for each
// color channel.
vec3 palette( float t, vec3 offset, vec3 amp, vec3 freq, vec3 phase)
{
    return offset + amp * cos(2.0 * PI * (freq * t + phase));
}

void main()
{
    // Coordinate System between -1..1, with 0, 0 at the center
    vec2 uv = (gl_FragCoord.xy * 2.0 - u_resolution.xy) / u_resolution.y;
    vec2 uv_original = uv;


    // STEP_9a
    // This value will be the final
    // color value; we add to it with each 
    // iteration in the for-loop
    vec3 color = vec3(0.);


    // STEP_9b
    // LAYERS
    // We create different layers for the design
    // with a for-loop. Each iteration modifies
    // the space coordinates 'uv' as well
    // as the color sampling
    for(float i = 0.; i < 3.; i++)
    {

        // STEP_8a
        // COORDINATE TRANSFORMATIONS
        // for creating repetition
        // uv = fract(uv * 2.0) - 0.5;
        // This will flip the negative values
        // to 1-v; e.g. fract(-0.2) = 0.8
        // * 2 increases the frequency
        // uv = fract(uv * 2.);

        // STEP_10
        // Breaking the clean repetition
        uv = fract(uv * 1.5);

        // We know that values range 0..1
        // hence we can shift them down
        // to put the center at the middle with -0.5
        uv -= 0.5;

        // STEP_1 
        // RADIAL LAYOUT
        // Mapping the coordinates from
        // a "rectangular" layout to a "radial" 
        // distance to the center at 0,0
        float d = length(uv);


        // STEP_11
        // Multiplying the "structural" value d
        // with an additional "global" radial ramp
        // from higher values at 0,0 to 
        // lower values at the edge of the canvas
        // with a very soft transition 
        // (have a look at exp(-x) in graphtoy)
        // d = exp(-length(uv_original));
        d *= exp(-length(uv_original));


        // STEP_2
        // Moving the "insides" of the circle
        // we want into negative space for
        // being able to distinguish being 
        // "inside" or outside of the circle
        // d -= 0.5;

        // STEP_4
        // WAVES
        // 1. d = sin(d * 8.) / 8.;
        // Creating multiple rings with sin 
        // by increasing the
        // frequency and decreasing
        // the amplitude as design choice to
        // balance the final design
        // 2. Adding u_time as offset, which
        // "moves" the sin curve along the axis
        d = sin(d * 8. + u_time) / 8.;
        // d = sin(d * 8.) / 8.;


        // STEP_3 
        // Flipping all negative values 
        // (which we see as black)
        // to positive values to create 
        // further visible detail
        d = abs(d);
        // A sharp edge for the circle
        // All values < 0.1 are black, the rest white (1)
        // d = step(0.1, d);

        // More control over the edge
        // with two thresholds
        // All values < 0.0 are black, all above 0.1 are white
        // and inbetween 0..0.1 there is a smooth transition
        // d = smoothstep(0.0, 0.1, d);

        // STEP_5
        // Inverting the function values
        // and pushing them to extreme high values
        // (have a look at the 0..1 range
        // of 0.02 / sin(x * 8) in graphtoy)
        // d = 0.02 / d;

        // STEP_12
        // Decrease values a bit
        // d = 0.01 / d;

        // STEP_14
        // Increase contrast
         d = pow(0.01 / d, 1.2);


        // STEP_7b
        // COLOR PALETTE
        // Animate the color mapping;
        // * 0.7 slows down the animation
        // float t = d;
        // float t = d + u_time;
        // float t = length(uv) + u_time * 0.7;

        // Keep in mind that the 4 vectors are not colors
        // but properties to shape a cos function
        // for each color channel
        // Also see the palette() definition above

        // STEP_8b
        // Use the original coordinate
        // over -1..1 as input for the color
        // float t = length(uv_original) + u_time * 0.7;

        // STEP_13
        // Adding an offset to the color sampling
        // for each iteration
        float t = length(uv_original) + u_time * 0.7 + i * 0.3;

        vec3 color_iteration = palette(t, vec3(0.5, 0.5, 0.5),
                            vec3(0.5, 0.5, 0.5), 
                            vec3(1.0, 1.0, 1.0), 
                            vec3(0.263,0.416,0.557));



        // STEP_6
        // Multiplying color
        // color *= d;


        // STEP_9c
        // Adding up all color values
        // from the iterations
        color += color_iteration * d;

    }


    // Mark values < 0 and > 1 red
    // gl_FragColor = (uv.y > 1. || uv.y < 0.) ? vec4(vec3(1., 0., 0.), 1.0) : vec4(vec3(uv.y), 1.0);
    // gl_FragColor = (d > 1. || d < 0.) ? vec4(vec3(1., 0., 0.), 1.0) : vec4(vec3(d), 1.0);
    // gl_FragColor = vec4(vec3(d), 1.0);
    // gl_FragColor = vec4(vec3(uv.y), 1.0);
    gl_FragColor = vec4(color, 1.0);

}



