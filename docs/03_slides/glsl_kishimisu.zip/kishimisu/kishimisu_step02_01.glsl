/* 
    Code by kishimisu
    ShaderToy: https://www.shadertoy.com/view/mtyGWy
    Tutorial: https://youtu.be/f4s1h2YETNY
*/


#ifdef GL_ES
precision mediump float;
#endif

uniform vec2 u_resolution;
uniform float u_time;

#define PI 3.14159265359





void main()
{
    // Coordinate System between -1..1, with 0, 0 at the center
    vec2 uv = (gl_FragCoord.xy * 2.0 - u_resolution.xy) / u_resolution.y;


    // STEP_1 RADIAL LAYOUT
    // Mapping the coordinates from
    // a "rectangular" layout to a "radial" 
    // distance to the center at 0,0
    float d = length(uv);


    // STEP_2
    // Moving the "insides" of the circle
    // we want into negative space for
    // being able to distinguish being 
    // "inside" or outside of the circle
    d -= 0.5;






    // Mark values < 0 and > 1 red
    // gl_FragColor = (uv.y > 1. || uv.y < 0.) ? vec4(vec3(1., 0., 0.), 1.0) : vec4(vec3(uv.y), 1.0);
    // gl_FragColor = (d > 1. || d < 0.) ? vec4(vec3(1., 0., 0.), 1.0) : vec4(vec3(d), 1.0);
    gl_FragColor = vec4(vec3(d), 1.0);
    // gl_FragColor = vec4(vec3(uv.y), 1.0);
    // gl_FragColor = vec4(color, 1.0);

}